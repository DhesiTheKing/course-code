class Main{
    public static void main(String [] args){
        int x = 5;
        int result = ++x * x++;
        System.out.println(result);
    }
    
    
}